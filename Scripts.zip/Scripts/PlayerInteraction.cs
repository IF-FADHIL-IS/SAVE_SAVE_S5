using UnityEngine;

public class PlayerInteraction : MonoBehaviour
{
    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Target"))
        {
            Debug.Log("Player menyentuh Target!");
        }
        else if (other.CompareTag("Obstacle"))
        {
            Debug.Log("Player menyentuh Obstacle!");
        }
    }

    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.CompareTag("Obstacle"))
        {
            Debug.Log("Player menabrak Obstacle!");
        }
    }
}